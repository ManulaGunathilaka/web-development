<?php

 if(isset($_POST['submit_btn']))
 {
  $username = $_POST['fname'];
  $password = $_POST['lname'];
  $password = $_POST['uname'];
  $password = $_POST['pwd'];

  $fp = fopen('data.txt', 'a+');

    if(fwrite($fp, $text))  {
        echo 'saved';

    }
fclose ($fp);    
}
?>